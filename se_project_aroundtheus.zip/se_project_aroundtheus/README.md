Project 3 Triple Ten - A Link to sprint 3 of the course, using figma and crrating the beging of the bootcamps next project.

LINK to GitHub pages: https://github.com/wearyshepherd/se_project_aroundtheus.git/index.html