Project 3: Around The U.S

The project incorporated the use of Figma and creating a webpage from scratch. We learned how to use media queries to make sure no mater what device was being used the page would be showen correctly.

[Project Around The U.S] https://github.com/wearyshepherd/se_project_aroundtheus.git

https://wearyshepherd.github.io/se_project_aroundtheus
